import { Container, Row, Col, Stack, Card } from 'react-bootstrap';
import { generateClient } from 'aws-amplify/data';

import { useState, useEffect } from 'react';
import { useLanguage } from './LanguageContext';

const currentSprint = 5;

export default function AboutPage () {
    const { t } = useLanguage();
    const client = generateClient();

    var [data, setData] = useState({
        sprintNo: 0,
        releaseDate: "00-00-0000",
        teamName: "Team 00",
        productName: "---",
        desc: "If you are reading this, there's no data to pull or your query has failed."
    });
    
    useEffect(() => {
        async function getAboutData() {
            try {
                // get a specific item
                const { data: info, errors } = await client.models.AboutInfo.get({
                    sprintNo: currentSprint
                });

                if (errors) {
                    console.log(errors);
                    return;
                }

                if (info) {
                    console.log(`Recived the following from the backend ${info}`)
                    setData({
                        sprintNo: info.sprintNo,
                        releaseDate: info.releaseDate,
                        teamName: info.teamName,
                        productName: info.productName,
                        desc: info.desc
                    });
                }
            } catch (err) {
                console.log(`ERROR: ${err}`)
            }
        } 

        getAboutData();

    }, []);

    return (
    <div style={{ position: "relative", minHeight: "100vh", padding: "30px" }}>
    <h1>{t('about.greeting')} <strong>{data.teamName}</strong></h1>

    <Container fluid>
        <div style={{ position: "relative", minHeight: "100vh", padding: "40px" }}>
            <Row>
                <Col>
                    <Card style={{ width: '18rem' }}>
                        <Card.Img variant="top" src="./truckIco.jpg" alt="Truck icon representing the SafeDrive product"/>
                        <Card.Body>
                            <Card.Title>{t('about.introducing')} {data.productName}</Card.Title>
                            <Card.Text>{data.desc}</Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
                <Col>
                    <Card style={{ width: '18rem' }}>
                        <Card.Img variant="top" src="./sprintIco.png" alt="Sprint icon indicating the current development sprint"/>
                        <Card.Body>
                            <Card.Title>{t('about.currentSprint')}</Card.Title>
                            <Card.Text>{data.sprintNo}</Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
                <Col>
                    <Card style={{ width: '18rem' }}>
                        <Card.Img variant="top" src="./calendarIco.png" alt="Calendar icon representing the next scheduled release date"/>
                        <Card.Body>
                            <Card.Title>{t('about.nextRelease')}</Card.Title>
                            <Card.Text>{data.releaseDate}</Card.Text>
                        </Card.Body>
                    </Card>
                </Col>
            </Row>
        </div>
      </Container>
    </div>
  );
}